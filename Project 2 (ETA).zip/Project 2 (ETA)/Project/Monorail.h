#ifndef MONORAIL_H
#define MONORAIL_H

#include "TransitMethod.h"
//Define the Transportation namespace
namespace Transportation {
    //Monorail class inherits
    class Monorail : public TransitMethod {
    private:
        double monorailSpeed;
        double waitTime;
        int monorailX;

    public:
        //constructor for the Monorail class
      Monorail(double walkSpeed, double railSpeed, double wait, double railX);

       double estimatedTime(double startX, double startY, double destX, double destY);
    };

} // namespace Transportation

#endif // MONORAIL_H