/*
 * Name: Luis Marte
 * Project 2: ETA
 * Course: CSI108 (Fall 2024)
 * Date: December 16, 2024
 * Description: Determine estimate time of arrival (ETA) based on
 *				method of transit used.
 */
#include <iostream>
#include <string>
#include <cmath>
#include "Walking.h" // the header for Walking transit method
#include "Taxi.h"   // the header for Taxi transit method
#include "Monorail.h" // the header for Monorail transit method
#include <fstream>  // for file 

using namespace Transportation; // I add the Transportation namespace

using namespace std;

// this is the function to reading the transit parameters from a file. 
static bool readTransitParameters(const string& filename, double& walkSpeed,
       double& driveSpeed, int& taxiX, int& taxiY, double& railSpeed, double& waitTime);



int main() 
{
    // Display estimated times rounded to 1/10 of an hour.
    cout.setf(ios::fixed);
    cout.precision(1);

    string timeOfDay;
    double walkSpeed, driveSpeed, railSpeed, waitTime;
    int taxiX, taxiY;

    // Allow user to choose time of day for trip, followed
    // by a source and then a destination in city.
    while (true) {
        cout << "\nTime of day transiting: " << endl;
        cout << "daytime" << endl;
        cout << "nighttime" << endl;
        cout << "quit (to exit)" << endl;
        cout << "Time: ";
        string timeOfDay;
        cin >> timeOfDay;
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // eat rest of line

        if (timeOfDay == "quit") // no more trips?
            break;

        //this read transit parameters base on the time chosen 
        if (!readTransitParameters(timeOfDay, walkSpeed, driveSpeed, taxiX, taxiY, railSpeed, waitTime)) {
            continue;
        }
        // Allow user to enter start and destination location.
        cout << endl;
        cout << "Enter locations as x and y mile markers" << endl;
        cout << "from center of city (ex: 12 -4)" << endl;

        cout << "\nStart (x y): ";
        int startX;
        int startY;
        cin >> startX >> startY;

        cout << "Destination (x y): ";
        int destX;
        int destY;
        cin >> destX >> destY;

        // Provide user with estimated time between start and
        // destination location for various transit methods.

        while (true) {
            cout << "\nChoose method of transit:" << endl;
            cout << "1) walking" << endl;
            cout << "2) taxi" << endl;
            cout << "3) monorail" << endl;
            cout << "0) next trip" << endl;
            cout << "Method: ";
            int method;
                cin >> method;

            if (method == 0) break; //exit the transit method selection loop

            TransitMethod* transitMethod = nullptr; 

            switch (method) {
            case 1:
                transitMethod = new Walking(walkSpeed);//create walking object
                break;
            case 2:
                transitMethod = new Taxi(walkSpeed, driveSpeed, taxiX, taxiY); //create taxi object
                break;
            case 3:
                transitMethod = new Monorail(walkSpeed, railSpeed, waitTime, 0); // create monorail object, and assuming monorail is at x=0
                break;
            default:
                    cout << "Unknown transit option: " << method << endl;;
                continue;
            }
           // calculate and display the estimated time for the selected transit method
            double estimatedTime = transitMethod->estimatedTime(startX, startY, destX, destY);
            cout << "Estimated time: " << estimatedTime << " hours\n";

            delete transitMethod; // Clean up the allocated
        }
    }

    return 0;
}

//function to read transit parameters from a file.
static bool readTransitParameters(const string& filename, double& walkSpeed, double& driveSpeed, int& taxiX, int& taxiY, double& railSpeed, double& waitTime)
{
    ifstream file("transit/" + filename + ".txt");
    if (!file) {
        cerr << "Cannot read transit parameters from: transit/" << filename << ".txt" << endl;
        return false;
    }
    file >> walkSpeed >> driveSpeed >> taxiX >> taxiY >> railSpeed >> waitTime;
    file.close();
    return true;
}
