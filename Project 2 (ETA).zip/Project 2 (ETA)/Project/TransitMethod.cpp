#include <iostream>
#include <cmath>
#include "TransitMethod.h"
using namespace std;

// Define Transportation 
namespace Transportation {

    //Constructor for the TransitMethod class
        TransitMethod::TransitMethod(double footSpeed) 
            : walkingSpeed(footSpeed) 
        {
        }

        // Destructor for the TransitMethod class
        TransitMethod::~TransitMethod()
        {
        }

        //Method to estimated the time required for a trip
        double TransitMethod::estimatedTime(double startX, double startY, double destX, double destY)
        {
            return 0.0;
        }

        //Method to calculate the Mahattan distance between two points
        double TransitMethod::manhattanDistance(double x1, double y1, double x2, double y2) {
            return abs(x1 - x2) + abs(y1 - y2);
        }
    };

