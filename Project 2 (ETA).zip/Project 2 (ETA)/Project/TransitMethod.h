#ifndef TRANSITMETHOD_H
#define TRANSITMETHOD_H


//Define the Transportation namespace
namespace Transportation {
    // Base class for various transit methods, all of which can
    // estimate time between 2 locations.
    class TransitMethod {
    protected:
        // Constructor to initialize the walking speed (mph).
        double walkingSpeed; 

    public:
        TransitMethod(double footSpeed); // constructor for the TransitMethod class
        virtual ~TransitMethod(); //Virtual destructor for the TransitMethod class

        // virtual method to estimate the time required for a trip
        virtual double estimatedTime(double startX, double startY, double destX, double destY);

        //Method to calculate the Manhattan distance between two points
        double manhattanDistance(double x1, double y1, double x2, double y2);
       
    };



} // namespace Transportation



#endif // TRANSITMETHOD_H