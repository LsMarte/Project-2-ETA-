
#include "Taxi.h"
#include "TransitMethod.h"
using namespace std;

//constructor for the Taxi class, and Initializations
Transportation::Taxi::Taxi(double walkSpeed, double driveSpeed, double standX, double standY)
         : TransitMethod(walkSpeed), drivingSpeed(driveSpeed), taxiStandX(standX), taxiStandY(standY) 
{
}

//this is a method to estimate the time required for a taxi trip and also calculates the total
//time base on the distance from the start location to the taxi stand and to the destination.
double Transportation::Taxi::estimatedTime(double startX, double startY, double destX, double destY)
{
    double distanceToTaxi = manhattanDistance(startX, startY, taxiStandX, taxiStandY);
    double distanceToDestination = manhattanDistance(taxiStandX, taxiStandY, destX, destY);
    return (distanceToTaxi + distanceToDestination) / drivingSpeed;
}

