#include "Monorail.h"
#include <iostream>
using namespace std;

    
//Construuctor  for the Monoreil class
 Transportation::Monorail::Monorail(double walkSpeed, double railSpeed, double wait, double railX) 
    : TransitMethod(walkSpeed), monorailSpeed(railSpeed), waitTime(wait), monorailX(railX)
 {
 }

 //Method to estimated the total time required for a trip using the monoreil
 // Calculates the time based on thoses.
  double Transportation::Monorail::estimatedTime(double startX, double startY, double destX, double destY) 
 {
        double walkToRail = manhattanDistance(startX, startY, monorailX, startY) / walkingSpeed;
        double railDistance = manhattanDistance(monorailX, startY, destX, destY) / monorailSpeed;
        double walkFromRail = manhattanDistance(destX, destY, monorailX, destY) / walkingSpeed;
        return walkToRail + waitTime + railDistance + walkFromRail;
 }

// namespace Transportation

        