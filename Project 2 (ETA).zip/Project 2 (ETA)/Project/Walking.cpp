
#include "TransitMethod.h"
#include "Walking.h"


// constructor for the Walking class
Transportation::Walking::Walking(double footSpeed)
: TransitMethod(footSpeed) // Initialize the base class
{
        
}

//Method to estimate the time required for a walking trip
double Transportation::Walking::estimatedTime(double startX, double startY, double destX, double destY)
{
    double distance = manhattanDistance(startX, startY, destX, destY);
    return distance / walkingSpeed;
}


//} // namespace Transportation



       