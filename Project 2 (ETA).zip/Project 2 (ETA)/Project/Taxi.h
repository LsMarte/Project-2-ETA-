#ifndef TAXI_H
#define TAXI_H

#include "TransitMethod.h"
//Define the Transportation namespace
namespace Transportation {
    // Taxi class that inherits from transitMethod
    class Taxi : public TransitMethod {
       // The coordinate of the stand
    private:
        int taxiStandX;
        int taxiStandY;
        double drivingSpeed;

    public:
        //constructor for the Taxi class
        Taxi(double walkSpeed, double driveSpeed, double standX, double standY);
        //Method to estimate the required for a taxi trip
        double estimatedTime(double startX, double startY, double destX, double destY);
          
       
    };

} // namespace Transportation

#endif // TAXI_H