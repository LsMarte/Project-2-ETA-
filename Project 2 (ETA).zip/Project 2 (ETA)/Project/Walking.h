#ifndef WALKING_H 
#define WALKING_H
#include <iostream>
#include "TransitMethod.h"

//Define the Transportation namespace
namespace Transportation {
    // Wlking class that inherits 
    class Walking : public TransitMethod {
    public:
        //constructor for the walking class
        Walking(double footSpeed);
        // Method to estimated the time required
        double estimatedTime(double startX, double startY, double destX, double destY);

    };
}; // namespace Transportation

#endif // WALKING_H